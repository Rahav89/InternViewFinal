﻿namespace InternViewServer.Models
{
    public class InternProcedureCounter
    {
        public int InternId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int InternsRating { get; set; }
        public string InternsYear { get; set; }
        public int ProcedureCount { get; set; }
        public int OverallNeed { get; set; }

    }
}
