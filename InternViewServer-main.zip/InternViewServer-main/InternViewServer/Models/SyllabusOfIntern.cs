﻿namespace InternViewServer.Models
{
    public class SyllabusOfIntern
    {
        public int procedure_Id { get; set; }
        public string procedureName { get; set; }
        public int syllabus { get; set; }
        public int haveDone { get; set; }
        public int need { get; set; }

    }
}
